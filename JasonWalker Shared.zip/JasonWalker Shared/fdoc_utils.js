// fdoc_utils 
// 1.3 2016-08-24 - Updated debugMsg to look for a txtDebug element in the page, instead of passing around a variable (error-prone due to different script scopes)
//     debugMsg is now slower, but more reliable. TODO - maybe find a faster/better way to handle that
//     Also fixed an error in "ArrayToTable", where the call to debugMsg would crash javascript when passed a simple value 
//      because it always tried to debug print the length of data[0]
//
// v1.2 2016-03-21 - Added ArrayToCSV function
// v1.2 2015-06-22 - More debug functions, added GetRelevanceResult() and
//		showElement() functions
// v1.1.1 2015-06-14 - Changed debugMsg to define var debug internally
// v1.1 2014-10-28 - ArrayToTableObject fixes
// v1.0 2014-10-24 Jason Walker, Lockheed Martin Corp

// function ErrMessage(strMessage)
// function debugMsg(strMessage)
// function ArrayJoin(data,sep1,sep2) 
// function ArrayToTable(data, attributes,blnHasHead,blnHasFoot)
// function ArrayToCheckboxTable(data,name)	
// function RelevanceObjectJoin
// function GetCheckedValues(name) 
// function UpdateDivHTML(DivID, innerHTML) 
// function GetValue(element)
// function PutValue(element)
// function ErrMessage(strMessage);

function ErrMessage(err, strMessage) {
	alert(strMessage + '; ' + err.message);
}

function showElement(oElement) {
	oElement.style.display="inline";
}

function GetRelevanceResult(strRelevance) {
	debugMsg ('GetRelevanceResult: Evaluating: ' + strRelevance + '\n\n');
  
 try {
	    var res2 = Relevance(strRelevance);
    }
    catch (e) {
        alert('Error: ' + e.message + '\nStatement:\n' + strRelevance);
            }
  return res2;
}

function GetValue(element) {
	try {
		debugMsg('Entered GetValue(' + element + ')');
		return document.getElementById(element).value;
	}
	catch (err){ErrMessage(err, 'GetValue(' + element + ' ) ')};
}

function PutValue(element, value) {
	try {
		debugMsg('Entered PutValue(' + element +', ' + value);
		document.getElementById(element).value=value;
		}
	catch(err) { ErrMessage(err, "PutValue")};
}

function ArrayToTable(data, attributes,blnHasHead,blnHasFoot)	{

	// Given a 1- or 2-dimension array, returns an HTML-formatted table of the array elements
	// Most likely use is to take a Relevance result which starts with an ID and may contain names, sites, etc. as additional cells
	debugMsg("Entered ArrayToTable();");
	var firstdatarow=0;
	var lastdatarow=data.length;
	debugMsg('ArrayToTable:lastdatarow=' + lastdatarow);
	if (typeof attributes === 'undefined') {	var attributes=""};
		
	debugMsg('ArrayToTable: style is ' + attributes);
	
	var blnSimple;
	var bln1d=false;
	var bln2d=false;
	var blnSimple=typeof data != "object";
		debugMsg("typeof data is " + typeof data);
		debugMsg("typeof data[0] is " + typeof data[0]);
		debugMsg("length of data is " + data.length + ", index of last data is " + lastdatarow);
	if (blnSimple != true) {
		bln1d=typeof data[0]!="object";
		bln2d=typeof data[0]=="object";
		}
	
	debugMsg("Simple=" + blnSimple + ", bln1d=" + bln1d + ", bln2d=" + bln2d);
	
	
	var content='<table ' + attributes + ' >';

	debugMsg("ArrayToTable: content is " + content);
	// Removed the Array check here - that may be a problem for single-column tables later though...
	if (blnHasHead) {
		debugMsg("ArrayToTable: building header row");
		content+="<thead><tr>";
		// Fixed this statement 2016-08-24; the check for data[0].length crashes script on 'simple' single-valued data
		if (blnSimple != true) { debugMsg("length of data[0] is " + data[0].length); }
		if (blnSimple) {
			//a simple single.  Note this *could* be valid even with blnHasHead - in which case the value is repeated on both header and data cell/row
			content += '<th>' + data + '</th>';
			
			} else if (bln1d) {	
				// a 1-d array/object, print the only row
				for ( var j = 0; j < data.length; j++) {
					content+= '<th>' + data[j] + '</th>';
					// since this is a 1d array with header, there is NO data row
					lastdatarow=0;
					}
			} else {
				// a 2-d array/object, print row 0
				for ( var j = 0; j < data[0].length; j++) {
					content+= '<th>' + data[0][j] + '</th>';
					}
			}
		content+="</tr></thead>";
		debugMsg("ArrayToTable: incrementing firstdatarow");
		firstdatarow++;
		}
		//debugMsg("ArrayToTable: Past Header, blnHasFoot=" + blnHasFoot);
		
	if (blnHasFoot) {
		lastdatarow--;
	}
	content+="<tbody>"
		debugMsg("ArrayToTable: Building the data; firstdatarow=" + firstdatarow + ", lastdatarow=" + lastdatarow);
		
	if (blnSimple) {
			//a simple single value
			debugMsg("ArrayToTable: Building simple table of single cell");
			content += '<tr><td>' + data + '</td></tr>';
	
			} else if (bln1d) {	
				// a 1-d array/object, print the only row
				debugMsg("ArrayToTable: Building a single-row table with " + data.length + " items");
				content +="<tr>"
				for ( var j = 0; j < data.length; j++) {
					content+= '<td>' + data[j] + '</td>';
					// since this is a 1d array with header, there is NO data row
					lastdatarow=0;
					}
				content +="</tr>";
					
			} else {
				// a 2-d array/object, print row 0
				debugMsg("Trying to build 2d table");
				debugMsg("ArrayToTable: Building a 2-d table with " + (lastdatarow - firstdatarow) + " rows and " + data[0].length + " columns");
				for (var i = firstdatarow; i < lastdatarow; i++) {
					debugMsg("row " + i);
					content +="<tr>";
					for ( var j = 0; j < data[i].length; j++) {
						//debugMsg("Cell [" + i + "][" + j + "]");
						content+= '<td>' + data[i][j] + '</td>';
						}
					content +="</tr>";
				}
				debugMsg("ArrayToTable: Built 2d table body with of " + content);
			}
	content+="</tbody>";
	//alert(content);
	if (blnHasFoot) {
		content+="<tfoot><tr>";
		if (bln2d) {
			// blnHasFoot makes no sense with a simple value or with a single-row
			if (typeof data[i] =="object") {
				for ( var j = 0; j < data[data.length - 1].length; j++) {
						content+= '<td>' + data[data.length - 1][j] + '</td>';
					}
				} else {
					content+= '<td>' + data[data.length - 1] + '</td>';
				}
			}
		content+="</tr></tfoot>"
		}
		
	content += '</table>';
	debugMsg(content);
	return content;
}

function ArrayToCSV(data)	{
	
	// Given a 2-dimension array, returns an HTML-formatted table of the array elements
	// Most likely use is to take a Relevance result which starts with an ID and may contain names, sites, etc. as additional cells
	
	var firstdatarow=0;
	var lastdatarow=data.length;
	debugMsg('lastdatarow=' + lastdatarow);
	debugMsg("Entered ArrayToCSV()");
	
	var blnSimple;
	var bln1d=false;
	var bln2d=false;
	var blnSimple=typeof data != "object";
		debugMsg("typeof data is " + typeof data);
		debugMsg("typeof data[0] is " + typeof data[0]);
		debugMsg("length of data is " + data.length + ", index of last data is " + lastdatarow);
	if (blnSimple != true) {
		bln1d=typeof data[0]!="object";
		bln2d=typeof data[0]=="object";
		}
	
	debugMsg("Simple=" + blnSimple + ", bln1d=" + bln1d + ", bln2d=" + bln2d);
	
	
	var content='';

	debugMsg("ArrayToCSV: content is " + content);
	// Removed the Array check here - that may be a problem for single-column tables later though...
	
	debugMsg("ArrayToTable: Building the data; firstdatarow=" + firstdatarow + ", lastdatarow=" + lastdatarow);
		
	if (blnSimple) {
			//a simple single value
			debugMsg("ArrayToCSV: Building simple table of single cell");
			content += '"' + String(data).replace('"','""') + '"';
	
			} else if (bln1d) {	
				// a 1-d array/object, print the only row
				debugMsg("ArrayToTable: Building a single-row table with " + data.length + " items");
				
				for ( var j = 0; j < data.length; j++) {
					if (j > 0) {
							content +=',';
					}
					content+= '"' + String(data[j]).replace('"','""') + '"';
					// since this is a 1d array with header, there is NO data row
					lastdatarow=0;
					}
				content +="\n";
					
			} else {
				// a 2-d array/object, print row 0
				debugMsg("Trying to build 2d table");
				debugMsg("ArrayToTable: Building a 2-d table with " + (lastdatarow - firstdatarow) + " rows and " + data[0].length + " columns");
				for (var i = firstdatarow; i < lastdatarow; i++) {
					debugMsg("row " + i);
					for ( var j = 0; j < data[i].length; j++) {
						//debugMsg("Cell [" + i + "][" + j + "]");
						if (j > 0) {
								content +=',';
						}
						content+= '"' + String(data[i][j]).replace('"','""') + '"';
						}
					content +="\n";
				}
				debugMsg("ArrayToTable: Built 2d table body with of " + content);
			}
		
	debugMsg(content);
	return content;
}

// While this version is newer, it did not solve the problem we had - that IE did not refresh newly-added elements 
//   and thus new tables were not made sortable.

function ArrayToTableObject(data, blnHasHead,blnHasFoot,objTable)	{

	// Given a 2-dimension array, returns a Table object that can be appended as a child to document or document element
	// Most likely use is to take a Relevance result which starts with an ID and may contain names, sites, etc. as additional cells
	
	// This probably does not work with a 1-dimensional array of strings
	
	// Unlike earlier versions, Attributes (such as id or name) should be applied by the caller
	// The input of objTable allows us to start working with an existing Table object, where things like "style" or "id" might be
	// defined before calling this function
	
	debugMsg("Entered ArrayToTableObject()");	
	
	var firstdatarow=0;
	var lastdatarow=data.length - 1;
	// create the new Element or reuse an existing one
	if (typeof objTable === 'undefined') {	
		var table = document.createElement('table');
		}
	else {
		var table=objTable;
	}
	var trow; var td; var tbody;

	// handle thead, if it has one
	// Note - doesn't seem to be documented, but creating a THEAD also creates a TBODY, at least in IE; so we wouldn't want to create a second TBODY later...
	if (blnHasHead) {
		debugMsg("ArrayToTable: building header row");
		var thead=table.createTHead();
		trow=document.createElement('tr');
		for ( var j = 0; j < data[0].length; j++) {
				td=document.createElement('th');
				td.innerHTML=data[0][j];
				trow.appendChild(td);
				thead.appendChild(trow);
			}
		firstdatarow++;
		}
		
// handle tfoot, if it has one		
	if (blnHasFoot) {
		debugMsg("ArrayToTable: building footer row");
		var tfoot=table.createTFoot();
		trow=document.createElement('tr');
		for ( var j = 0; j < data[lastdatarow].length; j++) {
			td=document.createElement('td');
			td.innerHTML=data[lastdatarow][j];
			trow.appendChild(td);
			tfoot.appendChild(trow);
			lastdatarow--;
			}
	
	}
	// handle body of table
	// If we created a THEAD, then IE also created a TBODY and we want to attach to it.
	// Or, the table may have come in with an existing TBODY so we'd wan't to append to it
	if (table.tBodies.length > 0) {
		tbody=table.tBodies[0];
		} else {
		tbody=document.createElement("tbody");
		table.appendChild(tbody);
		}

	for (var i = firstdatarow; i <= lastdatarow; i++) {
		debugMsg("ArrayToTable: building body row " + i);
		trow=document.createElement('tr');
		for ( var j = 0; j < data[i].length; j++) {
				td=document.createElement('td');
				td.innerHTML=data[i][j];
				trow.appendChild(td);
		}

		tbody.appendChild(trow);
	}
	return table;
}
function debugMsg(strMessage) {
	// Updated 2016-08-24 - it's too much trouble to scope variable for debug flag amongst multiple source scripts
	// Now just check for the presence of an element in the page and update it if it exists
	
	//if (typeof debug === 'undefined') {	var debug=false};
	//if (debug) { alert(strMessage)};
	if (document.getElementById("txtDebug")) {
	 document.getElementById("txtDebug").value += strMessage + '\n\n';
	}
}

// Removed in favor of newer version that checks dimensions, preserved for reference here
//
//function ArrayJoin(data,sep1,sep2) {
//	// Given a two-dimension array, builds a single string result
//	// Cells are delimited by "sep1", while rows are delimited by "sep2"
//	//   Ex: given [0][0]=id1, [0][1]=name1, [1][0]=id2, [1][1]=name2, sep1=";", sep2="\n", result is
//	//   id1;name1\nid2;name2
//	var content='';
//	for (var i = 0; i < data.length; i++) {
//		content +=data[i].join(sep1);
//		if (i < data.length - 1) {
//			content += sep2;
//		}
//	
//	}
//	return content;
//}

// Deprecated in favor of ArrayJoin checking types; preserved here for compatibility
function RelevanceObjectJoin(data,cellsep,rowsep)	{
	// Testing removal of separate ArrayJoin with RelevanceObjectJoin instead
	return ArrayJoin(data, cellsep, rowsep);
}
// Removed in favor of newer version that checks types and dimensions
//function RelevanceObjectJoinOrig(data,sep) {
//	// IF the data is an array, join the elements of the array using the given separator
//	// if it's NOT an array, just return the data itselv
//	
//	var content="";
//	if (data instanceof Array) {
//		for (var i = 0; i < data.length; i++) {
//    		content += data[i];
//			if (i < data.length - 1) {content += sep};
//		}
//	} else {
//		content=data;
//	}
//	return content;
//}


function ArrayJoin(data,cellsep,rowsep)	{
	// Given a RelevanceResult object of up to 2 dimensions, returns a string
	// Each Cell is separated by "sep2" while each Row is separated by "sep1"
	// Example: [0][0]=a.[0][1]=b,[1][0]=c,[1][1]=d; sep1=","; sep2="\n"; returns a,b\nc,d
	
	// This function is made to handle RelevanceResult objects, simple strings, or Arrays of one or two dimensions
	
	if (typeof cellsep === 'undefined') {	var cellsep=", "};
	if (typeof rowsep === 'undefined') {	var rowsep="; "};
	var content='';
	debugMsg("typeof data = " + typeof data);
	
	// Check whether the given data is an Object (RelevanceResult) or a simple string.  If a simple string, just return it.
	if (typeof data != "object") {
		debugMsg("data is a simple type, returning data");
		content += data;
		return content;
	}
	//It wasn't a simple string.  Handle a single-dimension or two-dimension RelevanceResult.
	// TODO - maybe this could be improved with recursion to handle more than two dimesions; but it's likely we'd want different separators at each dimension
	//   so that enhancement is left as an exercise for the reader
	
	for (var i = 0; i < data.length; i++) {
		debugMsg("row " + i + " ; typeof = " + typeof data[i]);
		// If this Row itself contains a RelevanceResult object, traverse through each Cell adding the Cell Separator
		if (typeof data[i] == "object") {
				for ( var j = 0; j < data[i].length; j++) {
					debugMsg("data[" + i + "][" + j + "] ; typeof = " + typeof data[i][j] + ", value= " + data[i][j]);
					content+= data[i][j];
					if (j < data[i].length -1) {content += cellsep};
				}
			} else {
			// This Row was not a RelevanceResult; assume a simple data type instead like "string" or "integer".  Append it, and if this is not the last row also append a row separator
				content += data[i];
				if (i < data.length - 1) {content += rowsep};
			}
	}
	debugMsg("RelevanceObjectJoin:Returning " + content);
	return content;
}

function GetCheckedValues(name) {
	// Given multiple checkboxes on a page with the given name, returns an array of the values for the checked boxes
	var results = new Array();
	var rel
	var checkboxes=document.getElementsByName(name);
	for (var i=0; i < checkboxes.length; i++) {
		if (checkboxes[i].checked) {
			results.push(checkboxes[i].value);
		}
	}
	return results;
}

function ArrayToCheckboxTable(data,name, attributes,blnHasHead,blnHasFoot)	{
	// Given a multi-dimension array, returns an HTML-formatted table of checkboxes
	// The name for the checkbox list is passed in
	// The value for each checkbox is set to the first item from each row in the 'data' array
	// Remaining cells on each row of the table are taken from the 'data' array
	// Most likely use is to take a Relevance result which starts with an ID and may contain names, sites, etc. as additional cells,
	// and build an array of checkboxes with values matching each ID
	
	if (typeof attributes === 'undefined') {	var attributes=""};
	if (typeof blnHasHead === 'undefined') {	var blnHasHead=false};
	if (typeof blnHasFoot === 'undefined') {	var blnHasFoot=false};
	
	var firstdatarow=0;
	var lastdatarow=data.length;
	
	var content='<table ' + attributes + '>';
	debugMsg('ArrayToCheckboxTable: Building Checkbox Array "' + name + '"');
	
	if (blnHasHead) {
		debugMsg("ArrayToCheckBoxTable: building header row");
		content+="<thead><tr>";
		// Insert a blank cell in the column where the checkboxes go
		content+="<th></th>";
		for ( var j = 0; j < data[0].length; j++) {
				content+= '<th>' + data[0][j] + '</th>';
			}
		content+="</tr></thead>"
		firstdatarow++;
		}
		
	if (blnHasFoot) {
		lastdatarow--;
	}
	
	content+="<tbody>";
	
	for (var i = firstdatarow; i < lastdatarow; i++) {
		//content+='<tr><td><input type="checkbox" name="' + name + '" id="' + name + data[i][0] + '" value="' + data[i][0] + '"></td>';
		debugMsg('i=' + i + ', data.length=' + data.length + ', data[i]=' + data[i] + ', IsArray=' + (data[i] instanceof Array));
				
		if (data[i] instanceof Array) {
			debugMsg(' Creating checkbox with value based on [i][j]');
			content+='<tr><td><input type="checkbox" name="' + name + '" value="' + data[i][0] + '"></td>';
		} else {
			debugMsg(' Creating checkbox with value based on [i]');
			content+='<tr><td><input type="checkbox" name="' + name + '" value="' + data[i] + '"></td>';
		}
		// If we are a two-dimensional array, build out the rest of the row based on the additional array dimensions
		if (data[i] instanceof Array) {
			debugMsg(' data[i] is an array, building a row of cells for each element');
			for ( var j = 0; j < data[i].length; j++) {
					content+= '<td>' + data[i][j] + '</td>';
				}
		} else {
			// Not a 2-dimensional array, just put out a cell with the label
				debugMsg(' data[i] is not array, building one cell for this element');
				content +='<td>' + data[i] + '</td>';
		}
			content+='</tr>\n';
	}
	content+="</tbody>";
	if (blnHasFoot) {
		content+="<tfoot><tr>";
		for ( var j = 0; j < data[data.length - 1].length; j++) {
				content+= '<td>' + data[data.length - 1][j] + '</td>';
			}
		content+="</tr></tfoot>"
		}
		
	content += '</table>';
	debugMsg(content);
	return content;
}

function UpdateDivHTML(DivID, innerHTML) {
	debugMsg('Updating ' + DivID + ' to ' + innerHTML);
	var div=document.getElementById(DivID);
	div.innerHTML=innerHTML;
	// STUPID hack for situations where IE will not display the new content...
	div.innerHTML=div.innerHTML;
}

